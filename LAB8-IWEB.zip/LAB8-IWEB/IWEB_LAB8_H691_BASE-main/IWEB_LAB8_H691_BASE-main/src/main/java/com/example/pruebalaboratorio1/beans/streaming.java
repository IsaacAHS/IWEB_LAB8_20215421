package com.example.pruebalaboratorio1.beans;

public class streaming {
    private int idStreaming;
    private String nombreServicio;

    public int getIdStreaming() {
        return idStreaming;
    }

    public void setIdStreaming(int idStreaming) {
        this.idStreaming = idStreaming;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }
}
